
export interface TranscriptionMessage {
  speaker: 'user' | 'ai';
  text?: string;
  isFinal?: boolean;
}

export interface UserProfile {
  name: string;
  bio: string;
  avatar?: string;
}