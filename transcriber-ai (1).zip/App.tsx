
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Blob } from '@google/genai';
import { TranscriptionMessage } from './types';
import { encode, decode, decodeAudioData } from './utils/audio';
import Auth from './components/Auth';
import Profile from './components/Profile';

enum AppState {
  Idle,
  Connecting,
  Recording,
  Error,
}

const MicrophoneIcon = ({ className }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path d="M8.25 4.5a3.75 3.75 0 1 1 7.5 0v8.25a3.75 3.75 0 1 1-7.5 0V4.5Z" />
        <path d="M6 10.5a.75.75 0 0 1 .75.75v1.5a5.25 5.25 0 1 0 10.5 0v-1.5a.75.75 0 0 1 1.5 0v1.5a6.75 6.75 0 1 1-13.5 0v-1.5A.75.75 0 0 1 6 10.5Z" />
    </svg>
);

const StopIcon = ({ className }: { className?: string }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
        <path fillRule="evenodd" d="M4.5 7.5a3 3 0 0 1 3-3h9a3 3 0 0 1 3 3v9a3 3 0 0 1-3-3h-9a3 3 0 0 1-3-3v-9Z" clipRule="evenodd" />
    </svg>
);

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
type LiveSession = Awaited<ReturnType<typeof ai.live.connect>>;

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [currentUserEmail, setCurrentUserEmail] = useState<string | null>(null);
  const [view, setView] = useState<'chat' | 'profile'>('chat');
  const [appState, setAppState] = useState<AppState>(AppState.Idle);
  const [transcriptionHistory, setTranscriptionHistory] = useState<TranscriptionMessage[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const sessionRef = useRef<LiveSession | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const isStoppingRef = useRef(false);
  // Fix: Add refs for gapless audio playback and interruption handling.
  const nextStartTimeRef = useRef(0);
  const audioSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  useEffect(() => {
    const sessionUser = sessionStorage.getItem('currentUserEmail');
    const localUser = localStorage.getItem('currentUserEmail');
    const userEmail = localUser || sessionUser;

    if (userEmail) {
      setIsAuthenticated(true);
      setCurrentUserEmail(userEmail);
    }
  }, []);

  const handleLoginSuccess = (email: string, remember: boolean) => {
      setCurrentUserEmail(email);
      setIsAuthenticated(true);
      if (remember) {
          localStorage.setItem('currentUserEmail', email);
      } else {
          sessionStorage.setItem('currentUserEmail', email);
      }
  };

  const stopSession = useCallback(() => {
    if (isStoppingRef.current) return;
    isStoppingRef.current = true;

    if (sessionRef.current) {
        sessionRef.current.close();
        sessionRef.current = null;
    }
    if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
        mediaStreamRef.current = null;
    }
    if (scriptProcessorRef.current) {
        scriptProcessorRef.current.disconnect();
        scriptProcessorRef.current = null;
    }
    if (inputAudioContextRef.current && inputAudioContextRef.current.state !== 'closed') {
        inputAudioContextRef.current.close();
    }
    if (outputAudioContextRef.current && outputAudioContextRef.current.state !== 'closed') {
        outputAudioContextRef.current.close();
    }
    // Fix: Clear audio sources and reset playback time on session stop.
    audioSourcesRef.current.forEach(source => source.stop());
    audioSourcesRef.current.clear();
    nextStartTimeRef.current = 0;
    setAppState(AppState.Idle);
    setTimeout(() => { isStoppingRef.current = false; }, 100);
  }, []);

  const handleLogout = () => {
      sessionStorage.removeItem('currentUserEmail');
      localStorage.removeItem('currentUserEmail');
      setIsAuthenticated(false);
      setCurrentUserEmail(null);
      if (appState !== AppState.Idle) {
        stopSession();
      }
  };

  const processTranscription = useCallback((message: LiveServerMessage) => {
    const process = (
        text: string,
        isFinal: boolean | undefined,
        speaker: 'user' | 'ai'
    ) => {
        setTranscriptionHistory(currentHistory => {
            const lastMessage = currentHistory[currentHistory.length - 1];
            if (lastMessage?.speaker === speaker && !lastMessage.isFinal) {
                const updatedHistory = [...currentHistory];
                updatedHistory[updatedHistory.length - 1] = {
                    ...lastMessage,
                    text: (lastMessage.text || '') + text,
                    isFinal,
                };
                return updatedHistory;
            } else {
                return [...currentHistory, { speaker, text, isFinal }];
            }
        });
    };

    // Fix: The 'isFinal' property is deprecated. Use 'turnComplete' to determine if a message is final.
    const isTurnComplete = !!message.serverContent?.turnComplete;
    if (message.serverContent?.inputTranscription) {
        const { text } = message.serverContent.inputTranscription;
        process(text, isTurnComplete, 'user');
    } else if (message.serverContent?.outputTranscription) {
        const { text } = message.serverContent.outputTranscription;
        process(text, isTurnComplete, 'ai');
    } else if (isTurnComplete) {
      setTranscriptionHistory(currentHistory => {
        if (currentHistory.length > 0) {
            const lastMessage = currentHistory[currentHistory.length - 1];
            if (lastMessage && !lastMessage.isFinal) {
                const updatedHistory = [...currentHistory];
                updatedHistory[updatedHistory.length - 1] = {
                    ...lastMessage,
                    isFinal: true,
                };
                return updatedHistory;
            }
        }
        return currentHistory;
      });
    }
  }, []);

  const startSession = useCallback(async () => {
    setAppState(AppState.Connecting);
    setErrorMessage(null);
    setTranscriptionHistory([]);

    try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            throw new Error('Your browser does not support the MediaDevices API.');
        }

        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaStreamRef.current = stream;
        
        const inputAudioCtx = new ((window as any).AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
        const outputAudioCtx = new ((window as any).AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        inputAudioContextRef.current = inputAudioCtx;
        outputAudioContextRef.current = outputAudioCtx;

        const source = inputAudioCtx.createMediaStreamSource(stream);
        const scriptProcessor = inputAudioCtx.createScriptProcessor(4096, 1, 1);
        scriptProcessorRef.current = scriptProcessor;

        const sessionPromise = ai.live.connect({
            // Fix: Use the recommended model for real-time audio conversation.
            model: 'gemini-2.5-flash-native-audio-preview-09-2025',
            callbacks: {
                onopen: () => {
                    setAppState(AppState.Recording);
                    scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                        const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                        const int16 = new Int16Array(inputData.length);
                        for (let i = 0; i < inputData.length; i++) {
                            int16[i] = inputData[i] * 32768;
                        }
                        const pcmBlob: Blob = {
                            data: encode(new Uint8Array(int16.buffer)),
                            mimeType: 'audio/pcm;rate=16000',
                        };
                        sessionPromise.then((session) => {
                            session.sendRealtimeInput({ media: pcmBlob });
                        });
                    };
                    source.connect(scriptProcessor);
                    scriptProcessor.connect(inputAudioCtx.destination);
                },
                onmessage: async (message: LiveServerMessage) => {
                    processTranscription(message);
                    const base64EncodedAudioString = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
                    if (base64EncodedAudioString && outputAudioCtx.state === 'running') {
                        // Fix: Implement gapless audio playback for a smoother experience.
                        const audioData = decode(base64EncodedAudioString);
                        const audioBuffer = await decodeAudioData(audioData, outputAudioCtx, 24000, 1);
                        
                        nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputAudioCtx.currentTime);

                        const sourceNode = outputAudioCtx.createBufferSource();
                        sourceNode.buffer = audioBuffer;
                        sourceNode.connect(outputAudioCtx.destination);
                        
                        audioSourcesRef.current.add(sourceNode);
                        sourceNode.addEventListener('ended', () => {
                          audioSourcesRef.current.delete(sourceNode);
                        });

                        sourceNode.start(nextStartTimeRef.current);
                        nextStartTimeRef.current += audioBuffer.duration;
                    }

                    if (message.serverContent?.interrupted) {
                      audioSourcesRef.current.forEach(source => source.stop());
                      audioSourcesRef.current.clear();
                      nextStartTimeRef.current = 0;
                    }
                },
                onerror: (e: ErrorEvent) => {
                    console.error('Session error:', e);
                    setErrorMessage('An error occurred. Please try again.');
                    setAppState(AppState.Error);
                    stopSession();
                },
                onclose: () => {
                    console.log('Session closed.');
                    stopSession();
                },
            },
            config: {
                responseModalities: [Modality.AUDIO],
                inputAudioTranscription: {},
                outputAudioTranscription: {},
                systemInstruction: "You are a helpful AI assistant. Your primary language is English. Only translate or switch languages when explicitly asked by the user."
            },
        });

        sessionPromise.then(session => {
            sessionRef.current = session;
        }).catch(err => {
            console.error('Failed to connect:', err);
            setErrorMessage('Failed to start session. Check microphone permissions.');
            setAppState(AppState.Error);
            stopSession();
        });

    } catch (error) {
        console.error('Error starting session:', error);
        let message = 'An unknown error occurred.';
        if (error instanceof Error) {
            if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') {
                message = 'Microphone access was denied. Please allow microphone access.';
            } else {
                message = error.message;
            }
        }
        setErrorMessage(message);
        setAppState(AppState.Error);
        stopSession();
    }
  }, [processTranscription, stopSession]);

  const handleMicClick = () => {
      if (appState === AppState.Recording) {
          stopSession();
      } else if (appState === AppState.Idle) {
          startSession();
      }
  };

  const renderChatHistory = () => (
      <div className="flex-grow overflow-y-auto p-4 md:p-6 space-y-4">
          {transcriptionHistory.length === 0 && (
              <div className="text-center text-gray-400 mt-8 flex flex-col items-center justify-center h-full">
                  <p className="text-lg">Click the microphone to start talking.</p>
              </div>
          )}
          {transcriptionHistory.map((msg, index) => (
              <div key={index} className={`flex ${msg.speaker === 'user' ? 'justify-end' : 'justify-start'} animate-slide-in-up`}>
                  <div className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-2 rounded-2xl ${msg.speaker === 'user' ? 'bg-blue-600 text-white rounded-br-none' : 'bg-gray-700 text-white rounded-bl-none'}`}>
                      <p>{msg.text}</p>
                  </div>
              </div>
          ))}
      </div>
  );

  const renderContent = () => {
      if (!isAuthenticated || !currentUserEmail) {
          return <Auth onLoginSuccess={handleLoginSuccess} />;
      }
      if (view === 'profile') {
          return <Profile userEmail={currentUserEmail} onBack={() => setView('chat')} />;
      }
      return (
          <div className="h-full w-full max-w-4xl flex flex-col">
              <div className="flex-grow flex flex-col bg-gray-800/80 backdrop-blur-sm shadow-xl rounded-2xl chat-background overflow-hidden">
                  {renderChatHistory()}
              </div>
              <div className="flex-shrink-0 p-4 text-center flex flex-col items-center">
                  <button onClick={handleMicClick} disabled={appState === AppState.Connecting} className="w-20 h-20 rounded-full bg-gradient-to-br from-purple-600 to-blue-500 text-white flex items-center justify-center shadow-lg transform hover:scale-110 transition-transform duration-200 disabled:opacity-50 disabled:cursor-not-allowed">
                      {appState === AppState.Recording ? <StopIcon className="w-10 h-10" /> : <MicrophoneIcon className="w-10 h-10" />}
                  </button>
                  {errorMessage && <p className="text-red-400 mt-4">{errorMessage}</p>}
              </div>
          </div>
      );
  };
  
  return (
    <div className="h-screen w-screen flex flex-col font-sans text-white">
      <header className="flex-shrink-0 flex items-center justify-between p-4 bg-black/30 backdrop-blur-sm">
        <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 text-transparent bg-clip-text">Transcriber AI</h1>
        {isAuthenticated && (
            <div className="flex items-center space-x-4">
                <button onClick={() => setView('profile')} className="px-4 py-2 text-sm font-medium text-white bg-gray-700/50 rounded-lg hover:bg-gray-600/50 transition-colors">Profile</button>
                <button onClick={handleLogout} className="px-4 py-2 text-sm font-medium text-white bg-red-600/80 rounded-lg hover:bg-red-700/80 transition-colors">Logout</button>
            </div>
        )}
      </header>
      <main className="flex-grow p-4 md:p-8 flex flex-col justify-center items-center overflow-hidden">
        {renderContent()}
      </main>
    </div>
  );
}