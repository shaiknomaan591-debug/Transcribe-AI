import React, { useState } from 'react';

interface AuthProps {
  onLoginSuccess: (email: string, remember: boolean) => void;
}

export default function Auth({ onLoginSuccess }: AuthProps) {
  const [isLoginView, setIsLoginView] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [error, setError] = useState('');

  const handleSignUp = () => {
    if (!email || !password) {
      setError('Email and password are required.');
      return;
    }
    const users = JSON.parse(localStorage.getItem('transcriber-users') || '{}');
    if (users[email]) {
        setError('An account with this email already exists.');
        return;
    }
    users[email] = password;
    localStorage.setItem('transcriber-users', JSON.stringify(users));
    alert('Account created successfully! Please log in.');
    setIsLoginView(true);
    setError('');
    setEmail('');
    setPassword('');
  };

  const handleLogin = () => {
    if (!email || !password) {
      setError('Email and password are required.');
      return;
    }
    const users = JSON.parse(localStorage.getItem('transcriber-users') || '{}');
    if (users[email] && users[email] === password) {
      setError('');
      onLoginSuccess(email, rememberMe);
    } else {
      setError('Invalid email or password.');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (isLoginView) {
      handleLogin();
    } else {
      handleSignUp();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center text-white font-sans p-4">
      <div className="w-full max-w-md p-8 space-y-6 bg-gray-900/80 backdrop-blur-md rounded-xl shadow-2xl">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-purple-400">
            {isLoginView ? 'Welcome Back' : 'Create Account'}
          </h1>
          <p className="mt-2 text-gray-300">
            {isLoginView ? 'Log in to continue to Transcriber AI' : 'Sign up to start your journey'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="email" className="text-sm font-bold text-gray-400 block mb-2">Email Address</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-2 text-white bg-gray-800 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
              placeholder="you@example.com"
              required
            />
          </div>
          <div>
            <label htmlFor="password"  className="text-sm font-bold text-gray-400 block mb-2">Password</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2 text-white bg-gray-800 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 transition-all"
              placeholder="••••••••"
              required
            />
          </div>

          {isLoginView && (
            <div className="flex items-center justify-between">
                <div className="flex items-center">
                    <input
                        id="remember-me"
                        name="remember-me"
                        type="checkbox"
                        checked={rememberMe}
                        onChange={(e) => setRememberMe(e.target.checked)}
                        className="h-4 w-4 rounded border-gray-600 bg-gray-700 text-purple-600 focus:ring-purple-500"
                    />
                    <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-400">
                        Remember me
                    </label>
                </div>
            </div>
          )}

          {error && <p className="text-sm text-red-400 text-center animate-pulse">{error}</p>}

          <div>
            <button type="submit" className="w-full px-8 py-3 mt-2 bg-gradient-to-r from-purple-600 to-blue-500 text-white font-bold rounded-full shadow-lg hover:scale-105 transform transition-transform duration-200 ease-in-out focus:outline-none focus:ring-4 focus:ring-blue-300">
              {isLoginView ? 'Login' : 'Sign Up'}
            </button>
          </div>
        </form>

        <p className="text-sm text-center text-gray-400">
          {isLoginView ? "Don't have an account? " : 'Already have an account? '}
          <button 
            onClick={() => { 
                setIsLoginView(!isLoginView); 
                setError(''); 
                setEmail('');
                setPassword('');
            }} 
            className="font-medium text-purple-400 hover:underline focus:outline-none"
          >
            {isLoginView ? 'Sign Up' : 'Login'}
          </button>
        </p>
      </div>
    </div>
  );
}
