import React, { useState, useEffect, useRef } from 'react';
import { UserProfile } from '../types';

interface ProfileProps {
  userEmail: string;
  onBack: () => void;
}

const DefaultAvatarIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path fillRule="evenodd" d="M18.685 19.097A9.723 9.723 0 0 0 21.75 12c0-5.385-4.365-9.75-9.75-9.75S2.25 6.615 2.25 12a9.723 9.723 0 0 0 3.065 7.097A9.716 9.716 0 0 0 12 21.75a9.716 9.716 0 0 0 6.685-2.653Zm-12.54-1.285A7.486 7.486 0 0 1 12 15a7.486 7.486 0 0 1 5.855 2.812A8.224 8.224 0 0 1 12 20.25a8.224 8.224 0 0 1-5.855-2.438ZM15.75 9a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0Z" clipRule="evenodd" />
  </svg>
);


const Profile: React.FC<ProfileProps> = ({ userEmail, onBack }) => {
  const profileKey = `transcriber-profile-${userEmail}`;
  const [profile, setProfile] = useState<UserProfile>({ name: '', bio: '', avatar: '' });
  const [isEditing, setIsEditing] = useState(false);
  const [savedMessage, setSavedMessage] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const storedProfile = localStorage.getItem(profileKey);
    if (storedProfile) {
      setProfile(JSON.parse(storedProfile));
    }
  }, [profileKey]);

  const handleSave = () => {
    localStorage.setItem(profileKey, JSON.stringify(profile));
    setIsEditing(false);
    setSavedMessage('Profile saved successfully!');
    setTimeout(() => setSavedMessage(''), 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setProfile({ ...profile, [e.target.name]: e.target.value });
  };
  
  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (loadEvent) => {
        if (loadEvent.target?.result) {
          setProfile({ ...profile, avatar: loadEvent.target.result as string });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <main className="flex-grow flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-2xl p-8 space-y-6 bg-gray-900/80 backdrop-blur-md rounded-xl shadow-2xl">
        <h2 className="text-3xl font-bold text-center text-purple-400">User Profile</h2>
        
        <div className="flex flex-col items-center space-y-4 pt-4">
            {profile.avatar ? (
                <img src={profile.avatar} alt="User Avatar" className="w-32 h-32 rounded-full object-cover border-4 border-purple-500 shadow-lg" />
            ) : (
                <div className="w-32 h-32 rounded-full bg-gray-700 flex items-center justify-center border-4 border-gray-600">
                    <DefaultAvatarIcon className="w-20 h-20 text-gray-500" />
                </div>
            )}
            {isEditing && (
                <>
                    <button 
                        onClick={() => fileInputRef.current?.click()}
                        className="px-4 py-2 text-sm bg-gray-700 text-white font-semibold rounded-lg hover:bg-gray-600 transition-colors"
                    >
                        Change Avatar
                    </button>
                    <input 
                        type="file" 
                        ref={fileInputRef} 
                        onChange={handleAvatarChange}
                        accept="image/*" 
                        className="hidden" 
                    />
                </>
            )}
        </div>

        <p className="text-center text-gray-400">{userEmail}</p>
        
        <div className="space-y-4">
          <div>
            <label className="text-sm font-bold text-gray-400 block mb-2">Name</label>
            {isEditing ? (
              <input
                type="text"
                name="name"
                value={profile.name}
                onChange={handleChange}
                className="w-full px-4 py-2 text-white bg-gray-800 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            ) : (
              <p className="p-3 bg-gray-800/50 rounded-lg min-h-[42px]">{profile.name || 'Not set'}</p>
            )}
          </div>
          <div>
            <label className="text-sm font-bold text-gray-400 block mb-2">Bio</label>
            {isEditing ? (
              <textarea
                name="bio"
                value={profile.bio}
                onChange={handleChange}
                className="w-full px-4 py-2 text-white bg-gray-800 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                rows={3}
              />
            ) : (
              <p className="p-3 bg-gray-800/50 rounded-lg min-h-[42px] whitespace-pre-wrap">{profile.bio || 'Not set'}</p>
            )}
          </div>
        </div>

        {savedMessage && <p className="text-center text-green-400 animate-pulse">{savedMessage}</p>}

        <div className="flex justify-between items-center pt-4">
          <button onClick={onBack} className="px-4 py-2 bg-gray-600 text-white font-semibold rounded-lg hover:bg-gray-700 transition-colors">Back to Chat</button>
          {isEditing ? (
            <button onClick={handleSave} className="px-6 py-2 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700 transition-colors">Save</button>
          ) : (
            <button onClick={() => setIsEditing(true)} className="px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors">Edit</button>
          )}
        </div>
      </div>
    </main>
  );
};

export default Profile;
